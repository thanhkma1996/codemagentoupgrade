<?php
namespace Packt\HelloWorld\Block\Adminhtml;
class Subscription extends \Magento\Backend\Block\Widget\Grid\Container
{
    protected function _construct(){
        $this->_blockGroup = 'Maganest_Movie';
        $this->_controller = 'adminhtml_subscription';
        parent::_construct();
    }
}