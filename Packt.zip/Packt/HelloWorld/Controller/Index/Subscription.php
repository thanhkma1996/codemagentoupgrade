<?php
namespace Packt\HelloWorld\Controller\Index;
class Subscription extends
    \Magento\Framework\App\Action\Action {
    public function execute() {
        $subscription = $this->_objectManager->create('Packt\HelloWorld\Model\Subscription');
        $subscription->setFirstname('Thanhkma');
        $subscription->setLastname('Nguyen');
        $subscription->setEmail('hoanganhthanh');
        $subscription->setMessage('messeger magento');
        $subscription->save();
        $this->getResponse()->setBody('success');
    }
    }