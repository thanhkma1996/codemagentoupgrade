<?php
namespace Packt\HelloWorld\Controller\Index;

class Collection extends \Magento\Framework\App\Action\Action
{
    public function execute()
    {

//        $productCollection = $this->_objectManager->create('Packt\HelloWorld\Model\ResourceModel\Subscription\Collection')->setPageSize(10,1)->getItems();
//         $x = $productCollection->getSelect()->__toString();

//        $output = '';
//        foreach ($productCollection as $key => $product) {
//
//
//            $output .= \Zend_Debug::dump($product->debug(), null, false);
//
//        }
//        $this->getResponse()->setBody($output);
        // $this->getResponse()->setBody('success');


//        $productCollection = $this->_objectManager->create('Magento\Catalog\Model\ResourceModel\Product\Collection')->addAttributeToSelect([
//                'name',
//                'price',
//                'image',
//            ])->setPageSize(10,1);
//                $output = '';
//                foreach ($productCollection as $product) {
//                $output .= \Zend_Debug::dump($product->debug(), null, false);
//                }
//                $this->getResponse()->setBody($output);

//
//        public function execute()
//        {
        $productCollection = $this->_objectManager->create('Magento\Catalog\Model\ResourceModel\Product\Collection')->addAttributeToSelect([
            'name',
            'price',
            'image',
        ])->addAttributeToFilter('name', 'Overnight Duffle');
        $output = '';
        foreach ($productCollection as $product) {
                $output .= \Zend_Debug::dump($product->debug(), null,
                    false);
//            $output = $productCollection->getSelect()->__toString();
        }
        $this->getResponse()->setBody($output);

    }
}

//        $productCollection = $this->_objectManager
//            ->create('Magento\Catalog\Model\ResourceModel\
//Product\Collection')
//            ->addAttributeToSelect([
//                'name',
//                'price',
//                'image',
//            ])
//            ->addAttributeToFilter('entity_id', array(
//                'in' => array(1, 1, 1)
//            ));
//        $output = '';
//        foreach ($productCollection as $product) {
//            $output .= \Zend_Debug::dump($product->debug(), null,
//                false);
//        }
//        $this->getResponse()->setBody($output);

//    }
//}