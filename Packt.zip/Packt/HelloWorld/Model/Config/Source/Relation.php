<?php
namespace Packt\HelloWorld\Model\Config\Source;
class Relation implements \Magento\Framework\Option\ArrayInterface
{
    public function toOptionArray()
    {
        return [
            [
                'value' => null,
                'label' => __('--Chon thuoc tinh--')
            ],
            [
                'value' => 'bongda',
                'label' => __('Bong Da')
            ],
            [
                'value' => 'vanhoa',
                'label' => __('Van hoa')
            ],
            [
                'value' => 'thethao',
                'label' => __('The Thao')
            ],
        ];
    }
}