<?php
namespace Maganest\Movie\Model\ResourceModel;
class Maganestdirector extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb {
    public function _construct() {
        $this->_init('maganest_director',
            'director_id');
    }
}