<?php
namespace Maganest\Movie\Model\ResourceModel;
class Maganestactor extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb {
    public function _construct() {
        $this->_init('maganest_actor',
            'actor_id');
    }
}