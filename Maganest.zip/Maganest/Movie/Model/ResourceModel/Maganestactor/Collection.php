<?php
namespace Maganest\Movie\Model\ResourceModel\Maganestactor;
/**
 * Subscription Collection
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection {
    /**
     * Initialize resource collection
     *
     * @return void
     */
    public function _construct() {
        $this->_init('Maganest\Movie\Model\Maganestactor',
            'Maganest\Movie\Model\ResourceModel\Maganestactor');
    }
}