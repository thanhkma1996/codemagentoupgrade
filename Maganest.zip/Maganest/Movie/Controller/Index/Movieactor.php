<?php
namespace Maganest\Movie\Controller\Index;
class Movieactor extends
    \Magento\Framework\App\Action\Action {
    public function execute() {
        $movie = $this->_objectManager->create('Maganest\Movie\Model\Movieactor');
        $movie->setactor_id('1');
        $movie->setmovie_id('2');
        $movie->save();
        $this->getResponse()->setBody('success');
    }
}