<?php
namespace Maganest\Movie\Controller\Index;
class Maganestdirector extends
    \Magento\Framework\App\Action\Action {
    public function execute() {
        $director = $this->_objectManager->create('Maganest\Movie\Model\Maganestdirector');
        $director->setname('Vai theu nam dinh');
        $director->save();
        $this->getResponse()->setBody('success');
    }
}