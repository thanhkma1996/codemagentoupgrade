<?php
namespace Maganest\Movie\Controller\Index;

class test2director extends \Magento\Framework\App\Action\Action {

    protected $resultPageFactory;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }
    public function execute()
    {
        $resultPage = $this->resultPageFactory->create();


        /** @var \Maganest\Movie\Model\ResourceModel\Maganestdirector\Collection $productCollection */
        $productCollection = $this->_objectManager->create('Maganest\Movie\Model\ResourceModel\Maganestdirector\Collection');
        $productCollection1 = $this->_objectManager->create('Maganest\Movie\Model\ResourceModel\Subscription\Collection');
//        ->addS
//        setPageSize(10,1)->getItems();
        //Select hadh where '1'='1
//        $productCollection->addFieldToSelect('*')
//            ->addFieldToFilter('id', [
//                'eq' => 1
//            ])
//            addField
//         $x = $productCollection->getSelect()->__toString()
        $productCollection1->addFieldToFilter('movie_id',1);
        $productCollection->addFieldToFilter('director_id',$productCollection1);
//        $productCollection->addAttributeToFilter('director_id','2');


        $output = '';
        foreach ($productCollection as $product) {


            $output .= \Zend_Debug::dump($product->debug(), null, false);

        }
        $this->getResponse()->setBody($output);

        return $resultPage;


    }

}