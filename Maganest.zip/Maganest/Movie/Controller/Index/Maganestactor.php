<?php
namespace Maganest\Movie\Controller\Index;
class Maganestactor extends
    \Magento\Framework\App\Action\Action {
    public function execute() {
        $actor = $this->_objectManager->create('Maganest\Movie\Model\Maganestactor');
        $actor->setname('Thu Ha');
        $actor->save();
        $this->getResponse()->setBody('success');
    }
}