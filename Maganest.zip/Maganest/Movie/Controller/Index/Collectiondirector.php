<?php
namespace Maganest\Movie\Controller\Index;

class Collectiondirector extends \Magento\Framework\App\Action\Action {
    public function execute() {
        /** @var \Maganest\Movie\Model\ResourceModel\Maganestdirector\Collection $productCollection */
        $productCollection = $this->_objectManager->create('Maganest\Movie\Model\ResourceModel\Maganestdirector\Collection');
//        ->addS
//        setPageSize(10,1)->getItems();
        //Select hadh where '1'='1
//        $productCollection->addFieldToSelect('*')
//            ->addFieldToFilter('id', [
//                'eq' => 1
//            ])
//            addField
//         $x = $productCollection->getSelect()->__toString()
        $productCollection->addFieldToFilter('director_id','2');
//        $productCollection->addAttributeToFilter('director_id','2');


        $output = '';
        foreach ($productCollection as $product) {


            $output .= \Zend_Debug::dump($product->debug(), null, false);

        }
        $this->getResponse()->setBody($output);
        // $this->getResponse()->setBody('success');
    }
}