<?php
namespace Maganest\Movie\Controller\Index;

class Collectionactor extends \Magento\Framework\App\Action\Action {
    public function execute() {

        $productCollection = $this->_objectManager->create('Maganest\Movie\Model\ResourceModel\Maganestactor\Collection')->setPageSize(10,1)->getItems();
        // $x = $productCollection->getSelect()->__toString();

        $output = '';
        foreach ($productCollection as $product) {


            $output .= \Zend_Debug::dump($product->debug(), null, false);

        }
        $this->getResponse()->setBody($output);
        // $this->getResponse()->setBody('success');
    }
}