<?php
namespace Maganest\Movie\Controller\Index;

class testmovie extends \Magento\Framework\App\Action\Action {
    public function execute() {
        /** @var \Maganest\Movie\Model\ResourceModel\Maganestdirector\Collection $productCollection */
        $productCollection = $this->_objectManager->create('Maganest\Movie\Model\ResourceModel\Movieactor\Collection');

        $productCollection->addFieldToFilter('movie_id','2');


        $output = '';
        foreach ($productCollection as $product) {


            $output .= \Zend_Debug::dump($product->debug(), null, false);

        }
        $this->getResponse()->setBody($output);
        // $this->getResponse()->setBody('success');
    }
}