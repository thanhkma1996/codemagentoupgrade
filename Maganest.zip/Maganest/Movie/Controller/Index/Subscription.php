<?php
namespace Maganest\Movie\Controller\Index;
class Subscription extends
    \Magento\Framework\App\Action\Action {
    public function execute() {
        $subscription = $this->_objectManager->create('Maganest\Movie\Model\Subscription');
        $subscription->setname('Thanhkma');
        $subscription->setdescription('xin chao moi nguoi');
        $subscription->setrating('1');
        $subscription->setdirector_id('2');
        $subscription->save();
        $this->getResponse()->setBody('success');
    }
    }