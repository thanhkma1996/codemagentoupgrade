<?php \Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::
    MODULE,
    'Maganest_Movie',
    __DIR__
);