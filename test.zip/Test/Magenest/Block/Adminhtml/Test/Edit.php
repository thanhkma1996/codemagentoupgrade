<?php
/**
 *
 */
namespace Test\Magenest\Block\Adminhtml\Test;
use Magento\Backend\Block\Widget\Form\Container as FormContainer;
use Magento\Framework\Registry;
use Magento\Backend\Block\Widget\Context;
class Edit extends FormContainer{
    protected $coreRegistry;

    public function __construct(
        Context $context,
        Registry $registry,
        array $data = [])
    {
        parent::__construct($context, $data);
    }

    public function getHeaderText()
    {
        $magenestMovie = $this->coreRegistry->registry('magenest_edit');
        if ($magenestMovie->getId())
        {
            return __("Edit Option '%1'", $this->escapeHtml($magenestMovie->getTitle()));
        }
        return __('New Option');
    }
    protected function _construct()
    {
        parent::_construct();
        $this->_objectId='member_id';
        $this->_blockGroup='Test_Magenest';
        $this->_controller = 'adminhtml_test';
        $this->buttonList->update('save', 'label', __('Save Magenest'));
        $this->removeButton('back');

        $this->addButton(
            'back_button',
            [
                'label' => __('Back'),
                'onclick' => 'setLocation(\'' . $this->getUrl('magenest/test/test') . '\')',
                'class' => 'back'
            ],
            -1
        );
    }
}