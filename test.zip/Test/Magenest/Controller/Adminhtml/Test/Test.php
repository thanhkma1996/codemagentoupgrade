<?php
namespace Test\Magenest\Controller\Adminhtml\Test;
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Test extends \Magento\Backend\App\Action {
    protected $resultPageFactory;

    public function __construct(Context $context, PageFactory $resultPageFactory) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    public function execute(){
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Test_Magenest::magenest');
        $resultPage->addBreadcrumb(__('Test'), __('Test'));
        $resultPage->addBreadcrumb(__('Magenest Test'), __('Magenest test'));
        $resultPage->getConfig()->getTitle()->prepend(__('Magenesttest'));
        return $resultPage;
    }
    protected function _isAllowed() {
        return $this->_authorization->isAllowed('Test_Magenest::magenest');
    }
}