<?php
namespace Test\Magenest\Controller\Adminhtml\Test;

class saveaddtest extends \Magento\Framework\App\Action\Action{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;


    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
    )
    {
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }

    /**
     * Default customer account page
     *
     * @return void
     */
    public function execute(){
        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        try{
            $request = $this->getRequest()->getParams();
            $movie = $this->_objectManager->create('Test\Magenest\Model\Test');
            $name = $request['name'];
            $phone = $request['phone'];
            $address = $request['address'];
//            $movie->setData($request);
            $movie->setName($name);
            $movie->setPhone($phone);
            $movie->setAddress($address);
            $this->_eventManager->dispatch(
                'adminhtml_magenest_prepare_save',
                ['magenest' => $movie]
            );

            $movie->save();

            $this->messageManager->addSuccessMessage('thanh cong');
            return $resultRedirect->setPath('magenest/test/test');
        }catch (\Exception $e){
            $this->messageManager->addExceptionMessage($e, __('We can\'t submit your request, Please try again.'));
            $this->_objectManager->get('Psr\Log\LoggerInterface')->critical($e);
            return $resultRedirect->setPath('contactus/index/index');
        }

    }

}
?>