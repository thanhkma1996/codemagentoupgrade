<?php
namespace Test\Magenest\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class UpgradeSchema implements UpgradeSchemaInterface {
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context){
        // TODO: Implement upgrade() method.
        if(version_compare($context->getVersion(),'2.0.1') < 0){
            $installer = $setup;
            $installer->startSetup();
            $connection = $installer->getConnection();

            //Install new database table
            $table = $installer->getConnection()->newTable(
                $installer->getTable('magenest_part_time')
            )->addColumn(
                'member_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,[
                'identity' => true,
                'unsigned' => true,
                'nullable' => false,
                'primary' => true
            ],
                'ID'
            )->addColumn(
                'create_time',
                \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
                null,[
                'nullable' => false,
                'default' => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT
            ],
                'Created time'
            )->addColumn(
                'updated_time',
                \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
                null,
                [],
                'Updated time'
            )->addColumn(
                'name',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                64,
                ['nullable' => false],
                'Customer name'
            )->addColumn(
                'address',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                64,
                ['nullable' => false],
                "Customer address "
            )->addColumn(
                'phone',
                \Magento\Framework\DB\Ddl\Table::TYPE_NUMERIC,
                255,
                ['nullable' => false],
                "Customer Phone"

            );
            $installer->getConnection()->createTable($table);
            $installer->endSetup();
        }
    }
}