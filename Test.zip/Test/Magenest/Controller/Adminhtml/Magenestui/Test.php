<?php
namespace Test\Magenest\Controller\Adminhtml\Magenestui;

use Magento\Framework\Controller\ResultFactory;

class Test extends \Magento\Backend\App\Action
{
    /**
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        return $resultPage;
    }
    protected	function _isAllowed()
    {
        return	$this->_authorization->isAllowed('Test_Magenest::magenestui');
    }
}