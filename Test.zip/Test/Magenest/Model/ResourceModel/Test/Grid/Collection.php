<?php
namespace Test\Magenest\Model\ResourceModel\Test\Grid;
/**
 * Subscription Collection
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection {
    /**
     * Initialize resource collection
     *
     * @return void
     */
    public function _construct() {
        $this->_init('Test\Magenest\Model\Test',
            'Test\Magenest\Model\ResourceModel\Test');
    }
}